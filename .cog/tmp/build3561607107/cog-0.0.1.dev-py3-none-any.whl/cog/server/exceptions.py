class CancelationException(Exception):
    pass


class FatalWorkerException(Exception):
    pass


class InvalidStateException(Exception):
    pass
